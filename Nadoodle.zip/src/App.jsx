import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import WalletConnection from './components/WalletConnection';
import MainMenu from './components/MainMenu';
import GameLobby from './components/GameLobby';
import GameRoom from './components/GameRoom';
import './App.css';

// Contract ABI (you'll need to compile and get the actual ABI)
const STAKING_CONTRACT_ABI = [
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "sessionId",
				"type": "string"
			}
		],
		"name": "cancelGame",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "sessionId",
				"type": "string"
			}
		],
		"name": "claimPrize",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "sessionId",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "stakeAmount",
				"type": "uint256"
			}
		],
		"name": "createGame",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "sessionId",
				"type": "string"
			},
			{
				"internalType": "address",
				"name": "winner",
				"type": "address"
			}
		],
		"name": "finishGame",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "string",
				"name": "sessionId",
				"type": "string"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "creator",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "stakeAmount",
				"type": "uint256"
			}
		],
		"name": "GameCreated",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "string",
				"name": "sessionId",
				"type": "string"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "winner",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "prizeAmount",
				"type": "uint256"
			}
		],
		"name": "GameFinished",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "amount",
				"type": "uint256"
			}
		],
		"name": "OwnerWithdrawal",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "string",
				"name": "sessionId",
				"type": "string"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "player",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "amount",
				"type": "uint256"
			}
		],
		"name": "PlayerStaked",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "string",
				"name": "sessionId",
				"type": "string"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "winner",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "amount",
				"type": "uint256"
			}
		],
		"name": "PrizeClaimed",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "sessionId",
				"type": "string"
			}
		],
		"name": "stakeForGame",
		"outputs": [],
		"stateMutability": "payable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "withdraw",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"name": "gameSessions",
		"outputs": [
			{
				"internalType": "address",
				"name": "creator",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "stakeAmount",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "totalStaked",
				"type": "uint256"
			},
			{
				"internalType": "bool",
				"name": "isActive",
				"type": "bool"
			},
			{
				"internalType": "bool",
				"name": "isFinished",
				"type": "bool"
			},
			{
				"internalType": "address",
				"name": "winner",
				"type": "address"
			},
			{
				"internalType": "bool",
				"name": "prizeClaimed",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "sessionId",
				"type": "string"
			}
		],
		"name": "getGameInfo",
		"outputs": [
			{
				"internalType": "address",
				"name": "creator",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "stakeAmount",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "totalStaked",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "stakedPlayersCount",
				"type": "uint256"
			},
			{
				"internalType": "bool",
				"name": "isActive",
				"type": "bool"
			},
			{
				"internalType": "bool",
				"name": "isFinished",
				"type": "bool"
			},
			{
				"internalType": "address",
				"name": "winner",
				"type": "address"
			},
			{
				"internalType": "bool",
				"name": "prizeClaimed",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "sessionId",
				"type": "string"
			}
		],
		"name": "getStakedPlayers",
		"outputs": [
			{
				"internalType": "address[]",
				"name": "",
				"type": "address[]"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "sessionId",
				"type": "string"
			},
			{
				"internalType": "address",
				"name": "player",
				"type": "address"
			}
		],
		"name": "hasPlayerStaked",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "owner",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"name": "playerBalances",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
];

// You'll need to deploy the contract and update this address
const STAKING_CONTRACT_ADDRESS = "0x54BE7EDC0A01ee90b0a3c54108DAAA205664DCA5"; // Replace with actual deployed address

const MONAD_TESTNET_CONFIG = {
  chainId: 10143,
  chainName: 'Monad Testnet',
  nativeCurrency: {
    name: 'MON',
    symbol: 'MON',
    decimals: 18,
  },
  rpcUrls: ['https://testnet-rpc.monad.xyz/'], // Replace with actual RPC URL
  blockExplorerUrls: ['https://testnet.monadexplorer.com/'], // Replace with actual explorer URL
};

function App() {
  const [walletConnected, setWalletConnected] = useState(false);
  const [account, setAccount] = useState('');
  const [provider, setProvider] = useState(null);
  const [signer, setSigner] = useState(null);
  const [contract, setContract] = useState(null);
  const [currentScreen, setCurrentScreen] = useState('wallet'); // wallet, menu, lobby, game
  const [gameSession, setGameSession] = useState(null);
  const [isRoomCreator, setIsRoomCreator] = useState(false);
  const [multisynqSession, setMultisynqSession] = useState(null);

  // Check if wallet is already connected on load
  useEffect(() => {
    checkWalletConnection();
  }, []);

  const checkWalletConnection = async () => {
    if (typeof window.ethereum !== 'undefined') {
      try {
        const accounts = await window.ethereum.request({ method: 'eth_accounts' });
        if (accounts.length > 0) {
          await connectWallet();
        }
      } catch (error) {
        console.error('Error checking wallet connection:', error);
      }
    }
  };

  const connectWallet = async () => {
    if (typeof window.ethereum === 'undefined') {
      alert('Please install MetaMask to play this game!');
      return;
    }

    try {
      // Request account access
      const accounts = await window.ethereum.request({ 
        method: 'eth_requestAccounts' 
      });

      // Check if connected to Monad testnet
      const chainId = await window.ethereum.request({ method: 'eth_chainId' });
      if (parseInt(chainId, 16) !== MONAD_TESTNET_CONFIG.chainId) {
        await switchToMonadTestnet();
      }

      const provider = new ethers.BrowserProvider(window.ethereum);
      const signer = await provider.getSigner();
      const contract = new ethers.Contract(STAKING_CONTRACT_ADDRESS, STAKING_CONTRACT_ABI, signer);

      setAccount(accounts[0]);
      setProvider(provider);
      setSigner(signer);
      setContract(contract);
      setWalletConnected(true);
      setCurrentScreen('menu');

    } catch (error) {
      console.error('Error connecting wallet:', error);
      alert('Failed to connect wallet. Please try again.');
    }
  };

  const switchToMonadTestnet = async () => {
    try {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: `0x${MONAD_TESTNET_CONFIG.chainId.toString(16)}` }],
      });
    } catch (switchError) {
      // This error code indicates that the chain has not been added to MetaMask
      if (switchError.code === 4902) {
        try {
          await window.ethereum.request({
            method: 'wallet_addEthereumChain',
            params: [MONAD_TESTNET_CONFIG],
          });
        } catch (addError) {
          throw new Error('Failed to add Monad testnet to MetaMask');
        }
      } else {
        throw switchError;
      }
    }
  };

  const initializeMultisynq = async (sessionId) => {
    if (!window.Multisynq) {
      alert('MultiSynq is still loading. Please try again in a moment.');
      return null;
    }

    try {
      const session = await window.Multisynq.Session.join({
        apiKey: "2i4fuBK4GNLqtVfz5z4VTfQhAKCQBWiMgMEsvTsQ2L",
        appId: "com.skribbl.monad",
        model: class GameModel {
          constructor() {
            this.gameState = {
              currentRound: 1,
              currentDrawer: null,
              currentWord: '',
              timeLeft: 30,
              isRoundActive: false,
              drawingStrokes: [],
              players: [],
              scores: {},
              gameFinished: false,
              winner: null
            };
            this.chatMessages = [];
          }
        },
        view: class GameView {
          constructor(model) {
            this.model = model;
          }
        },
        name: sessionId,
        password: "game-session"
      });

      setMultisynqSession(session);
      return session;
    } catch (error) {
      console.error('Error initializing MultiSynq:', error);
      return null;
    }
  };

  const createRoom = async (roomConfig) => {
    try {
      const sessionId = `room_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      // Create game on smart contract
      const stakeAmountWei = ethers.parseEther(roomConfig.stakeAmount.toString());
      const tx = await contract.createGame(sessionId, stakeAmountWei);
      await tx.wait();

      setGameSession({
        id: sessionId,
        ...roomConfig,
        creator: account,
        players: [],
        stakedPlayers: []
      });
      setIsRoomCreator(true);
      setCurrentScreen('lobby');
    } catch (error) {
      console.error('Error creating room:', error);
      alert('Failed to create room. Please try again.');
    }
  };

  const joinRoom = async (sessionId) => {
    setGameSession({
      id: sessionId,
      creator: null, // Will be fetched from contract
      players: [],
      stakedPlayers: []
    });
    setIsRoomCreator(false);
    setCurrentScreen('lobby');
  };

  const startGame = () => {
    setCurrentScreen('game');
  };

  const leaveRoom = () => {
    setGameSession(null);
    setIsRoomCreator(false);
    setCurrentScreen('menu');
  };

  const renderCurrentScreen = () => {
    if (!walletConnected) {
      return <WalletConnection onConnect={connectWallet} />;
    }

    switch (currentScreen) {
      case 'menu':
        return (
          <MainMenu
            account={account}
            onCreateRoom={createRoom}
            onJoinRoom={joinRoom}
          />
        );
      case 'lobby':
        return (
          <GameLobby
            gameSession={gameSession}
            account={account}
            contract={contract}
            isRoomCreator={isRoomCreator}
            onStartGame={startGame}
            onLeaveRoom={leaveRoom}
          />
        );
      case 'game':
        return gameSession ? (
          <GameRoom
            gameSession={gameSession}
            account={account}
            contract={contract}
            isRoomCreator={isRoomCreator}
            multisynqSession={multisynqSession}
            onLeaveRoom={leaveRoom}
          />
        ) : null;
      default:
        return <WalletConnection onConnect={connectWallet} />;
    }
  };

  return (
    <div className="app">
      {renderCurrentScreen()}
    </div>
  );
}

export default App;