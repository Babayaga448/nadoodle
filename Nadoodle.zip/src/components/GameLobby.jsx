import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';

const GameLobby = ({ gameSession, account, contract, isRoomCreator, onStartGame, onLeaveRoom }) => {
  const [players, setPlayers] = useState([]);
  const [nickname, setNickname] = useState('');
  const [editingNickname, setEditingNickname] = useState(false);
  const [playerNicknames, setPlayerNicknames] = useState({});
  const [gameInfo, setGameInfo] = useState(null);
  const [hasStaked, setHasStaked] = useState(false);
  const [staking, setStaking] = useState(false);

  useEffect(() => {
    // Set initial nickname from wallet address
    setNickname(`Player_${account.slice(-4)}`);
    fetchGameInfo();
    
    // Set up polling for game state updates
    const interval = setInterval(fetchGameInfo, 3000);
    return () => clearInterval(interval);
  }, [gameSession.id, account]);

  const fetchGameInfo = async () => {
    try {
      const info = await contract.getGameInfo(gameSession.id);
      const [creator, stakeAmount, totalStaked, stakedPlayersCount, isActive, isFinished, winner, prizeClaimed] = info;
      
      setGameInfo({
        creator,
        stakeAmount: ethers.formatEther(stakeAmount),
        totalStaked: ethers.formatEther(totalStaked),
        stakedPlayersCount: Number(stakedPlayersCount),
        isActive,
        isFinished,
        winner,
        prizeClaimed
      });

      // Check if current user has staked
      const userStaked = await contract.hasPlayerStaked(gameSession.id, account);
      setHasStaked(userStaked);

      // Get staked players
      const stakedPlayers = await contract.getStakedPlayers(gameSession.id);
      setPlayers(stakedPlayers);

    } catch (error) {
      console.error('Error fetching game info:', error);
    }
  };

  const handleStake = async () => {
    if (!gameInfo) return;
    
    setStaking(true);
    try {
      const stakeAmountWei = ethers.parseEther(gameInfo.stakeAmount);
      const tx = await contract.stakeForGame(gameSession.id, { value: stakeAmountWei });
      await tx.wait();
      
      setHasStaked(true);
      fetchGameInfo(); // Refresh game state
      alert('Successfully staked! You can now play.');
    } catch (error) {
      console.error('Error staking:', error);
      alert('Failed to stake. Please try again.');
    } finally {
      setStaking(false);
    }
  };

  const handleNicknameSubmit = (e) => {
    e.preventDefault();
    if (nickname.trim()) {
      setPlayerNicknames(prev => ({
        ...prev,
        [account]: nickname.trim()
      }));
      setEditingNickname(false);
    }
  };

  const canStartGame = () => {
    return isRoomCreator && gameInfo && gameInfo.stakedPlayersCount >= 2;
  };

  const handleStartGame = () => {
    // Add a small delay to ensure all staked players are properly synced
    onStartGame();
  };

  const getPlayerNickname = (address) => {
    return playerNicknames[address] || `Player_${address.slice(-4)}`;
  };

  const copyRoomId = () => {
    navigator.clipboard.writeText(gameSession.id);
    alert('Room ID copied to clipboard!');
  };

  if (!gameInfo) {
    return (
      <div className="card">
        <h2>Loading lobby...</h2>
      </div>
    );
  }

  return (
    <div className="lobby fade-in">
      <div className="lobby-header">
        <h1>Game Lobby</h1>
        <button className="btn btn-secondary" onClick={copyRoomId}>
          📋 Copy Room ID
        </button>
      </div>

      <div className="lobby-info">
        <h3>Room Information</h3>
        <p><strong>Room ID:</strong> {gameSession.id}</p>
        <p><strong>Creator:</strong> {gameInfo.creator.slice(0, 6)}...{gameInfo.creator.slice(-4)}</p>
        <p><strong>Minimum Stake:</strong> {gameInfo.stakeAmount} MON</p>
        <p><strong>Rounds:</strong> {gameSession.rounds || 3}</p>
        <p><strong>Time per Drawing:</strong> {gameSession.timeLimit || 30} seconds</p>
        <p><strong>Total Staked:</strong> {gameInfo.totalStaked} MON</p>
        <p><strong>Staked Players:</strong> {gameInfo.stakedPlayersCount}</p>
      </div>

      {/* Nickname Section */}
      <div className="players-list">
        <h3>Your Nickname</h3>
        {editingNickname ? (
          <form onSubmit={handleNicknameSubmit} className="nickname-form">
            <input
              type="text"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              className="input"
              placeholder="Enter your nickname..."
              maxLength={20}
              autoFocus
            />
            <button type="submit" className="btn">Save</button>
            <button 
              type="button" 
              className="btn btn-secondary"
              onClick={() => setEditingNickname(false)}
            >
              Cancel
            </button>
          </form>
        ) : (
          <div className="nickname-display">
            <p><strong>Current nickname:</strong> {getPlayerNickname(account)}</p>
            <button 
              className="btn btn-secondary"
              onClick={() => setEditingNickname(true)}
            >
              Edit Nickname
            </button>
          </div>
        )}
      </div>

      {/* Players List */}
      <div className="players-list">
        <h3>Players ({players.length})</h3>
        {players.length === 0 ? (
          <p style={{ textAlign: 'center', color: '#666', fontStyle: 'italic' }}>
            No players have staked yet...
          </p>
        ) : (
          players.map((playerAddress, index) => (
            <div key={playerAddress} className="player-item">
              <div className="player-info">
                <div className="player-nickname">
                  {index + 1}. {getPlayerNickname(playerAddress)}
                </div>
                <div className="player-address">
                  {playerAddress.slice(0, 6)}...{playerAddress.slice(-4)}
                  {playerAddress === account && ' (You)'}
                </div>
              </div>
              <div className="player-status status-staked">
                Staked
              </div>
            </div>
          ))
        )}
      </div>

      {/* Action Buttons */}
      <div className="lobby-actions">
        {!hasStaked ? (
          <button 
            className="btn" 
            onClick={handleStake}
            disabled={staking}
          >
            {staking ? 'Staking...' : `Stake ${gameInfo.stakeAmount} MON`}
          </button>
        ) : (
          <div className="player-status status-staked" style={{ padding: '12px 24px' }}>
            You have staked and are ready to play!
          </div>
        )}

        {isRoomCreator && (
          <button 
            className="btn" 
            onClick={handleStartGame}
            disabled={!canStartGame()}
          >
            {canStartGame() ? 'Start Game' : `Need ${Math.max(0, 2 - gameInfo.stakedPlayersCount)} more staked players`}
          </button>
        )}

        <button className="btn btn-secondary" onClick={onLeaveRoom}>
          Leave Room
        </button>
      </div>

      {gameInfo.stakedPlayersCount < 2 && (
        <div style={{ 
          textAlign: 'center', 
          marginTop: '20px', 
          padding: '16px', 
          backgroundColor: 'rgba(255, 20, 147, 0.1)',
          borderRadius: '8px',
          border: '2px dashed #ff1493'
        }}>
          <p><strong>Waiting for more players...</strong></p>
          <p>Share the room ID with friends to invite them!</p>
          <p>Minimum 2 staked players required to start.</p>
        </div>
      )}
    </div>
  );
};

export default GameLobby;