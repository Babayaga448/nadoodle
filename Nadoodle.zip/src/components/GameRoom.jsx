import React, { useState, useRef, useEffect } from 'react';

// Word bank (you can replace with your 200 words)
const WORD_BANK = [
  'cat', 'dog', 'house', 'tree', 'car', 'sun', 'moon', 'star', 'flower', 'bird',
  'fish', 'apple', 'banana', 'chair', 'table', 'book', 'phone', 'computer', 'pizza', 'guitar',
  'piano', 'ball', 'shoe', 'hat', 'clock', 'mountain', 'ocean', 'bridge', 'castle', 'rocket',
  'placeholder1', 'placeholder2', 'placeholder3' // Add your 200 words here
];

const GameRoom = ({ gameSession, account, contract, isRoomCreator, multisynqSession, onLeaveRoom }) => {
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentStroke, setCurrentStroke] = useState([]);
  
  // Local game state
  const [gameState, setGameState] = useState({
    currentRound: 1,
    currentDrawer: null,
    currentWord: '',
    timeLeft: gameSession.timeLimit || 30,
    isRoundActive: false,
    drawingStrokes: [],
    players: [],
    scores: {},
    gameFinished: false,
    winner: null
  });
  
  const [chatMessages, setChatMessages] = useState([]);
  const [chatInput, setChatInput] = useState('');
  const [wordOptions, setWordOptions] = useState([]);
  const [hasGuessedCorrectly, setHasGuessedCorrectly] = useState(false);
  const [connectedUsers, setConnectedUsers] = useState([]);

  // Simulate connected users
  useEffect(() => {
    setConnectedUsers([
      { id: account, nickname: `Player_${account.slice(-4)}` }
    ]);
  }, [account]);

  // Timer effect
  useEffect(() => {
    let timer;
    if (gameState.isRoundActive && gameState.timeLeft > 0) {
      timer = setTimeout(() => {
        setGameState(prev => ({
          ...prev,
          timeLeft: prev.timeLeft - 1
        }));
      }, 1000);
    } else if (gameState.timeLeft === 0 && gameState.isRoundActive) {
      endCurrentRound();
    }
    return () => clearTimeout(timer);
  }, [gameState.timeLeft, gameState.isRoundActive]);

  // Initialize game
  useEffect(() => {
    if (isRoomCreator && !gameState.currentDrawer) {
      initializeGame();
    }
  }, [isRoomCreator, gameState.currentDrawer]);

  const initializeGame = () => {
    const playerList = connectedUsers.map(user => ({
      id: user.id,
      nickname: user.nickname || `Player_${user.id.slice(-4)}`,
      address: account
    }));

    const newGameState = {
      ...gameState,
      players: playerList,
      scores: Object.fromEntries(playerList.map(p => [p.id, 0])),
      currentDrawer: playerList[0]?.id,
    };

    setGameState(newGameState);
    startNextRound();
  };

  const startNextRound = () => {
    if (gameState.currentRound > (gameSession.rounds || 3)) {
      endGame();
      return;
    }

    const options = getRandomWords(3);
    setWordOptions(options);
    setHasGuessedCorrectly(false);

    const newGameState = {
      ...gameState,
      timeLeft: gameSession.timeLimit || 30,
      isRoundActive: false,
      drawingStrokes: [],
      currentWord: '',
    };

    setGameState(newGameState);
  };

  const getRandomWords = (count) => {
    const shuffled = [...WORD_BANK].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
  };

  const selectWord = (word) => {
    const newGameState = {
      ...gameState,
      currentWord: word,
      isRoundActive: true,
      timeLeft: gameSession.timeLimit || 30
    };

    setGameState(newGameState);
    setWordOptions([]);
  };

  const endCurrentRound = () => {
    const currentIndex = gameState.players.findIndex(p => p.id === gameState.currentDrawer);
    const nextIndex = (currentIndex + 1) % gameState.players.length;
    
    let nextRound = gameState.currentRound;
    if (nextIndex === 0) {
      nextRound += 1;
    }

    const newGameState = {
      ...gameState,
      currentRound: nextRound,
      currentDrawer: gameState.players[nextIndex]?.id,
      isRoundActive: false,
      currentWord: '',
    };

    setGameState(newGameState);

    setTimeout(() => {
      if (nextRound <= (gameSession.rounds || 3)) {
        startNextRound();
      } else {
        endGame();
      }
    }, 3000);
  };

  const endGame = async () => {
    const winner = Object.entries(gameState.scores).reduce((a, b) => 
      gameState.scores[a[0]] > gameState.scores[b[0]] ? a : b
    );

    const newGameState = {
      ...gameState,
      gameFinished: true,
      winner: winner[0]
    };

    setGameState(newGameState);

    if (isRoomCreator) {
      try {
        const winnerPlayer = gameState.players.find(p => p.id === winner[0]);
        if (winnerPlayer && contract) {
          const tx = await contract.finishGame(gameSession.id, winnerPlayer.address);
          await tx.wait();
        }
      } catch (error) {
        console.error('Error finishing game on contract:', error);
      }
    }
  };

  // Drawing functions
  const startDrawing = (e) => {
    if (gameState.currentDrawer !== connectedUsers.find(u => u.id === account)?.id) return;
    
    setIsDrawing(true);
    const rect = canvasRef.current.getBoundingClientRect();
    const point = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
      color: '#000'
    };
    setCurrentStroke([point]);
  };

  const draw = (e) => {
    if (!isDrawing || gameState.currentDrawer !== connectedUsers.find(u => u.id === account)?.id) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const point = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
      color: '#000'
    };
    setCurrentStroke(prev => [...prev, point]);
  };

  const stopDrawing = () => {
    if (isDrawing && currentStroke.length > 0) {
      const newGameState = {
        ...gameState,
        drawingStrokes: [...gameState.drawingStrokes, currentStroke]
      };
      setGameState(newGameState);
      setCurrentStroke([]);
    }
    setIsDrawing(false);
  };

  // Render canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw completed strokes
    gameState.drawingStrokes.forEach(stroke => {
      if (stroke.length > 1) {
        ctx.beginPath();
        ctx.moveTo(stroke[0].x, stroke[0].y);
        stroke.forEach(point => ctx.lineTo(point.x, point.y));
        ctx.strokeStyle = stroke[0].color || '#000';
        ctx.lineWidth = 3;
        ctx.lineCap = 'round';
        ctx.stroke();
      }
    });

    // Draw current stroke
    if (currentStroke.length > 1) {
      ctx.beginPath();
      ctx.moveTo(currentStroke[0].x, currentStroke[0].y);
      currentStroke.forEach(point => ctx.lineTo(point.x, point.y));
      ctx.strokeStyle = '#000';
      ctx.lineWidth = 3;
      ctx.lineCap = 'round';
      ctx.stroke();
    }
  }, [gameState.drawingStrokes, currentStroke]);

  const handleChatSubmit = (e) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const isCurrentDrawer = gameState.currentDrawer === connectedUsers.find(u => u.id === account)?.id;
    const isCorrectGuess = chatInput.toLowerCase().trim() === gameState.currentWord.toLowerCase() && !isCurrentDrawer;

    let messageType = 'normal';
    let points = 0;

    if (isCorrectGuess && !hasGuessedCorrectly) {
      messageType = 'correct';
      points = Math.max(1, Math.floor(gameState.timeLeft / 5));
      setHasGuessedCorrectly(true);

      const userId = connectedUsers.find(u => u.id === account)?.id;
      const newGameState = {
        ...gameState,
        scores: {
          ...gameState.scores,
          [userId]: (gameState.scores[userId] || 0) + points
        }
      };
      setGameState(newGameState);
    } else if (isCorrectGuess && hasGuessedCorrectly) {
      return;
    }

    const message = {
      id: Date.now(),
      text: isCurrentDrawer ? chatInput : (isCorrectGuess ? `Correct! +${points} points` : chatInput),
      sender: connectedUsers.find(u => u.id === account)?.nickname || 'Player',
      type: messageType,
      timestamp: Date.now()
    };

    setChatMessages(prev => [...prev, message]);
    setChatInput('');
  };

  const clearCanvas = () => {
    if (gameState.currentDrawer === connectedUsers.find(u => u.id === account)?.id) {
      const newGameState = {
        ...gameState,
        drawingStrokes: []
      };
      setGameState(newGameState);
    }
  };

  const claimPrize = async () => {
    try {
      if (contract) {
        const tx = await contract.claimPrize(gameSession.id);
        await tx.wait();
        alert('Prize claimed successfully!');
      }
    } catch (error) {
      console.error('Error claiming prize:', error);
      alert('Failed to claim prize. Please try again.');
    }
  };

  const isCurrentDrawer = gameState.currentDrawer === connectedUsers.find(u => u.id === account)?.id;
  const currentDrawerName = gameState.players.find(p => p.id === gameState.currentDrawer)?.nickname || 'Unknown';

  if (gameState.gameFinished) {
    const winnerName = gameState.players.find(p => p.id === gameState.winner)?.nickname || 'Unknown';
    const isWinner = gameState.winner === connectedUsers.find(u => u.id === account)?.id;

    return (
      <div className="game-room">
        <div className="modal-overlay">
          <div className="modal bounce-in">
            <h1>Game Finished!</h1>
            <h2>Winner: {winnerName}</h2>
            
            <div className="scoreboard">
              <h3>Final Scores:</h3>
              {Object.entries(gameState.scores)
                .sort(([,a], [,b]) => b - a)
                .map(([playerId, score]) => {
                const player = gameState.players.find(p => p.id === playerId);
                return (
                  <div key={playerId} className="score-item">
                    <span>{player?.nickname || 'Unknown'}</span>
                    <span>{score} points</span>
                  </div>
                );
              })}
            </div>

            <div style={{ marginTop: '24px' }}>
              {isWinner && (
                <button className="btn" onClick={claimPrize}>
                  🏆 Claim Your Prize!
                </button>
              )}
              <button className="btn btn-secondary" onClick={onLeaveRoom}>
                Leave Game
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="game-room">
      <div className="game-header">
        <div className="game-info">
          <div className="timer">⏰ {gameState.timeLeft}s</div>
          <div>Round {gameState.currentRound}/{gameSession.rounds || 3}</div>
          <div>Players: {connectedUsers.length}</div>
        </div>
        
        <button className="btn btn-secondary" onClick={onLeaveRoom}>
          Leave Game
        </button>
      </div>

      <div className="game-content">
        <div className="canvas-area">
          {/* Word Selection */}
          {isCurrentDrawer && wordOptions.length > 0 && (
            <div className="word-selection">
              <h3>Choose a word to draw:</h3>
              <div className="word-options">
                {wordOptions.map((word, index) => (
                  <button
                    key={index}
                    className="word-option"
                    onClick={() => selectWord(word)}
                  >
                    {word}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Current word display */}
          {gameState.currentWord && (
            <div className="current-drawer">
              {isCurrentDrawer ? (
                <strong>You are drawing: "{gameState.currentWord}"</strong>
              ) : (
                <strong>{currentDrawerName} is drawing...</strong>
              )}
            </div>
          )}

          {/* Drawing Canvas */}
          <canvas
            ref={canvasRef}
            width={600}
            height={400}
            className="drawing-canvas"
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
            style={{
              cursor: isCurrentDrawer ? 'crosshair' : 'default',
              pointerEvents: gameState.isRoundActive ? 'auto' : 'none'
            }}
          />

          {/* Drawing Controls */}
          {isCurrentDrawer && gameState.isRoundActive && (
            <div style={{ marginTop: '16px' }}>
              <button className="btn btn-secondary" onClick={clearCanvas}>
                Clear Canvas
              </button>
            </div>
          )}

          {/* Round Status */}
          {!gameState.isRoundActive && !gameState.gameFinished && (
            <div style={{ 
              textAlign: 'center', 
              padding: '20px',
              backgroundColor: 'rgba(255, 20, 147, 0.1)',
              borderRadius: '8px',
              margin: '16px 0'
            }}>
              {wordOptions.length > 0 ? (
                <p>Waiting for {currentDrawerName} to choose a word...</p>
              ) : (
                <p>Round ended! Next round starting soon...</p>
              )}
            </div>
          )}
        </div>

        <div className="sidebar">
          {/* Players & Scores */}
          <div className="players-sidebar">
            <h3>Players & Scores</h3>
            {gameState.players.map(player => (
              <div key={player.id} className="score-item">
                <span>
                  {player.nickname}
                  {player.id === gameState.currentDrawer && ''}
                  {player.id === connectedUsers.find(u => u.id === account)?.id && ' (You)'}
                </span>
                <span>{gameState.scores[player.id] || 0} pts</span>
              </div>
            ))}
          </div>

          {/* Chat */}
          <div className="chat-area">
            <h3>Chat</h3>
            <div className="chat-messages">
              {chatMessages.map(message => (
                <div key={message.id} className={`chat-message ${message.type}`}>
                  <strong>{message.sender}:</strong> {message.text}
                </div>
              ))}
            </div>
            
            <form onSubmit={handleChatSubmit} className="chat-input-area">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                className="input chat-input"
                placeholder={
                  isCurrentDrawer 
                    ? "You're drawing! Chat with players..." 
                    : hasGuessedCorrectly
                    ? "You guessed correctly! Wait for others..."
                    : "Type your guess..."
                }
                disabled={hasGuessedCorrectly && !isCurrentDrawer}
              />
              <button type="submit" className="btn" disabled={!chatInput.trim()}>
                Send
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GameRoom;