import React, { useState } from 'react';

const MainMenu = ({ account, onCreateRoom, onJoinRoom }) => {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [showJoinForm, setShowJoinForm] = useState(false);
  const [formData, setFormData] = useState({
    stakeAmount: 0.1,
    rounds: 3,
    timeLimit: 30
  });
  const [roomId, setRoomId] = useState('');

  const handleCreateRoom = (e) => {
    e.preventDefault();
    if (formData.stakeAmount <= 0) {
      alert('Stake amount must be greater than 0');
      return;
    }
    onCreateRoom(formData);
  };

  const handleJoinRoom = (e) => {
    e.preventDefault();
    if (!roomId.trim()) {
      alert('Please enter a room ID');
      return;
    }
    onJoinRoom(roomId.trim());
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  if (showCreateForm) {
    return (
      <div className="card fade-in">
        <h2>Create New Room</h2>
        
        <form onSubmit={handleCreateRoom} className="room-form">
          <div className="form-group">
            <label>Minimum MON Stake Required</label>
            <input
              type="number"
              step="0.1"
              min="0.1"
              value={formData.stakeAmount}
              onChange={(e) => handleInputChange('stakeAmount', parseFloat(e.target.value))}
              className="input"
              required
            />
            <small style={{ color: '#666', fontSize: '12px' }}>
              Players must stake this amount to participate
            </small>
          </div>

          <div className="form-group">
            <label>Number of Rounds</label>
            <select
              value={formData.rounds}
              onChange={(e) => handleInputChange('rounds', parseInt(e.target.value))}
              className="input"
            >
              <option value={1}>1 Round</option>
              <option value={2}>2 Rounds</option>
              <option value={3}>3 Rounds</option>
              <option value={4}>4 Rounds</option>
              <option value={5}>5 Rounds</option>
            </select>
            <small style={{ color: '#666', fontSize: '12px' }}>
              1 round = all players get to draw once
            </small>
          </div>

          <div className="form-group">
            <label>Time Limit per Drawing (seconds)</label>
            <div className="form-row">
              <input
                type="range"
                min="10"
                max="60"
                value={formData.timeLimit}
                onChange={(e) => handleInputChange('timeLimit', parseInt(e.target.value))}
                className="input"
                style={{ flex: 2 }}
              />
              <span style={{ minWidth: '60px', textAlign: 'center', fontWeight: 'bold' }}>
                {formData.timeLimit}s
              </span>
            </div>
          </div>

          <div className="menu-buttons">
            <button type="submit" className="btn">
              Create Room
            </button>
            <button 
              type="button" 
              className="btn btn-secondary"
              onClick={() => setShowCreateForm(false)}
            >
              Back
            </button>
          </div>
        </form>
      </div>
    );
  }

  if (showJoinForm) {
    return (
      <div className="card fade-in">
        <h2>Join Room</h2>
        
        <form onSubmit={handleJoinRoom} className="room-form">
          <div className="form-group">
            <label>Room ID</label>
            <input
              type="text"
              value={roomId}
              onChange={(e) => setRoomId(e.target.value)}
              className="input"
              placeholder="Enter room ID to join..."
              required
            />
            <small style={{ color: '#666', fontSize: '12px' }}>
              Get the room ID from the room creator
            </small>
          </div>

          <div className="menu-buttons">
            <button type="submit" className="btn">
              Join Room
            </button>
            <button 
              type="button" 
              className="btn btn-secondary"
              onClick={() => setShowJoinForm(false)}
            >
              Back
            </button>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="card fade-in">
      <h1>Skribbl Monad</h1>
      
      <div className="wallet-info">
        <h3>Welcome!</h3>
        <p>Connected: {account.slice(0, 6)}...{account.slice(-4)}</p>
      </div>

      <div className="menu-buttons">
        <button 
          className="btn"
          onClick={() => setShowCreateForm(true)}
        >
          Create Room
        </button>
        
        <button 
          className="btn btn-secondary"
          onClick={() => setShowJoinForm(true)}
        >
          Join Room
        </button>
      </div>

      <div style={{ marginTop: '24px', fontSize: '14px', color: '#666' }}>
        <h4>How to Play:</h4>
        <ul style={{ textAlign: 'left', marginTop: '8px' }}>
          <li>Take turns drawing words</li>
          <li>Guess what others are drawing</li>
          <li>Faster guesses = more points</li>
          <li>Winner takes the entire stake pot!</li>
        </ul>
      </div>
    </div>
  );
};

export default MainMenu;