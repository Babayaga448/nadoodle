import React from 'react';

const WalletConnection = ({ onConnect }) => {
  return (
    <div className="card fade-in">
      <h1>Skribbl Monad</h1>
      <div className="wallet-info">
        <h3>Connect Your Wallet to Play</h3>
        <p>You need to connect your MetaMask wallet and be on Monad Testnet to join the fun!</p>
      </div>
      
      <div className="requirements">
        <h4>Requirements:</h4>
        <ul style={{ textAlign: 'left', marginTop: '12px' }}>
          <li>MetaMask wallet installed</li>
          <li>Connected to Monad Testnet (Chain ID: 10143)</li>
          <li>Some MON tokens for staking</li>
        </ul>
      </div>
      
      <button className="btn" onClick={onConnect} style={{ marginTop: '24px' }}>
        Connect MetaMask
      </button>
      
      <div style={{ marginTop: '20px', fontSize: '14px', color: '#666' }}>
        <p>Don't have MON tokens? Get them from the Monad testnet faucet!</p>
      </div>
    </div>
  );
};

export default WalletConnection;